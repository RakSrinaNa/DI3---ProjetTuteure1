var group__Print =
[
    [ "Print_preview", "group__Print.html#gad98ad0399c2fee28e9e7c6d2f74525dd", null ],
    [ "PrintFormat_format", "group__Print.html#ga439f9d07cf972958a4258d9b9b0ca164", null ]
];