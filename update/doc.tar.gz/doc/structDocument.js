var structDocument =
[
    [ "customer", "structDocument.html#ae09cf2ecc5299bb3926980664c473fd3", null ],
    [ "docNumber", "structDocument.html#a1606cdf3e0822d63297a546f4f0172dc", null ],
    [ "editDate", "structDocument.html#a312899691f7ecdb742ca28504d7238c5", null ],
    [ "expiryDate", "structDocument.html#ad473f0686021470bca3be3ceae698139", null ],
    [ "object", "structDocument.html#a698139783a57ed0223f42bff714b914b", null ],
    [ "operator", "structDocument.html#a4929e9d61af65aab9bcf3eae097f2555", null ],
    [ "rows", "structDocument.html#afb959b3b54681ede558d5e86b9990661", null ],
    [ "typeDocument", "structDocument.html#ad2e6abc5a91c6708161b80bba3facc28", null ]
];