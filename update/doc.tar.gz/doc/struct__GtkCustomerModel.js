var struct__GtkCustomerModel =
[
    [ "clientDB", "struct__GtkCustomerModel.html#a2dfd227c0e9e9c42c12424b48e9ce0ba", null ],
    [ "parent", "struct__GtkCustomerModel.html#a119e262dd6f86f1488d00a7ce2d28abf", null ],
    [ "shouldCloseDB", "struct__GtkCustomerModel.html#aa9ba3ae86adc8c2b1efe995e7d600ea8", null ],
    [ "stamp", "struct__GtkCustomerModel.html#a0fa107e460911891fac8f819b2e7220b", null ]
];