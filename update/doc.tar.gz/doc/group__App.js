var group__App =
[
    [ "App_run", "group__App.html#ga564bea34c350b6eb513aa2ac2e512c5f", null ],
    [ "MainWindow_create", "group__App.html#ga0f92704dd268924f59a056459a53d495", null ]
];