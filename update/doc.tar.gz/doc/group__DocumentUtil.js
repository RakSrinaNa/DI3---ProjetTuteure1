var group__DocumentUtil =
[
    [ "computeDocumentNumber", "group__DocumentUtil.html#ga71c5eeffedf48e921edac2c8e802b6a7", null ],
    [ "formatDate", "group__DocumentUtil.html#ga5c14603f3e92d6210df73843247d828c", null ],
    [ "readString", "group__DocumentUtil.html#ga8b95856984309ee3bb50c4caa7259d63", null ],
    [ "writeString", "group__DocumentUtil.html#ga348551b99f417ea31489dabc3a7e1779", null ]
];