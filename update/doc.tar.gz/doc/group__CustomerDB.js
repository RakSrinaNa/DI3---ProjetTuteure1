var group__CustomerDB =
[
    [ "CustomerDB", "structCustomerDB.html", [
      [ "CustomerDB_appendRecord", "group__CustomerDB.html#gaefaa5cc0e3b64b57babf177350809419", null ],
      [ "CustomerDB_close", "group__CustomerDB.html#ga49ad4472c10433a5bcb111ddf7a5d56b", null ],
      [ "CustomerDB_create", "group__CustomerDB.html#gab40e45188e169da65e44e8e278486e29", null ],
      [ "CustomerDB_getFieldValueAsString", "group__CustomerDB.html#ga989a5870ad30ebf203409d34b1c2432e", null ],
      [ "CustomerDB_getRecordCount", "group__CustomerDB.html#ga7229666153701e0e44c7522e7b848613", null ],
      [ "CustomerDB_insertRecord", "group__CustomerDB.html#gada390c313707bb7e184036e438872651", null ],
      [ "CustomerDB_open", "group__CustomerDB.html#ga1c2b5cee888f572992b21f323039ef18", null ],
      [ "CustomerDB_openOrCreate", "group__CustomerDB.html#gaafca52f13d030d9f2096064ab5efb444", null ],
      [ "CustomerDB_readRecord", "group__CustomerDB.html#ga03605b3b1a76149b39e2d9aa72a508d5", null ],
      [ "CustomerDB_removeRecord", "group__CustomerDB.html#ga5bdc043ab31737fc0aa136dc26080946", null ],
      [ "CustomerDB_writeRecord", "group__CustomerDB.html#ga4f052abd0c61e5ee1b188bbe01fe2fd7", null ],
      [ "file", "structCustomerDB.html#a702945180aa732857b380a007a7e2a21", null ],
      [ "recordCount", "structCustomerDB.html#af2b3801705d4d78cc1f2ede923a177e6", null ]
    ] ],
    [ "CustomerDB_appendRecord", "group__CustomerDB.html#gaefaa5cc0e3b64b57babf177350809419", null ],
    [ "CustomerDB_close", "group__CustomerDB.html#ga49ad4472c10433a5bcb111ddf7a5d56b", null ],
    [ "CustomerDB_create", "group__CustomerDB.html#gab40e45188e169da65e44e8e278486e29", null ],
    [ "CustomerDB_getFieldValueAsString", "group__CustomerDB.html#ga989a5870ad30ebf203409d34b1c2432e", null ],
    [ "CustomerDB_getRecordCount", "group__CustomerDB.html#ga7229666153701e0e44c7522e7b848613", null ],
    [ "CustomerDB_insertRecord", "group__CustomerDB.html#gada390c313707bb7e184036e438872651", null ],
    [ "CustomerDB_open", "group__CustomerDB.html#ga1c2b5cee888f572992b21f323039ef18", null ],
    [ "CustomerDB_openOrCreate", "group__CustomerDB.html#gaafca52f13d030d9f2096064ab5efb444", null ],
    [ "CustomerDB_readRecord", "group__CustomerDB.html#ga03605b3b1a76149b39e2d9aa72a508d5", null ],
    [ "CustomerDB_removeRecord", "group__CustomerDB.html#ga5bdc043ab31737fc0aa136dc26080946", null ],
    [ "CustomerDB_writeRecord", "group__CustomerDB.html#ga4f052abd0c61e5ee1b188bbe01fe2fd7", null ],
    [ "CUSTOMERDB_FILENAME", "group__CustomerDB.html#gad5f7d3454b595fab6dbd14470e96098b", null ]
];