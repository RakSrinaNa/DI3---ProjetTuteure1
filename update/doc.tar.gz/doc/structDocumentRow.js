var structDocumentRow =
[
    [ "basePrice", "structDocumentRow.html#aa202ff7ac9da4792e13c732cecd057cd", null ],
    [ "code", "structDocumentRow.html#a5b9e1322ebc26e12c192f03bccba2770", null ],
    [ "designation", "structDocumentRow.html#a238af89adb357ae219950bae456a4d07", null ],
    [ "discount", "structDocumentRow.html#a53313c66e4ab6acce975994de1d9c097", null ],
    [ "next", "structDocumentRow.html#ab8e4a43b29c4ba6631b64a7172297c3c", null ],
    [ "quantity", "structDocumentRow.html#a42a7cbf17ad499bb36ad798c4bb46973", null ],
    [ "rateOfVAT", "structDocumentRow.html#a9b94cceae6d68929f7e6065540058f1d", null ],
    [ "sellingPrice", "structDocumentRow.html#a3ba5a6e4bf38bba226358967cfa33302", null ],
    [ "unity", "structDocumentRow.html#a9e8ebe5266edb99433e33a7e8b8956ce", null ]
];