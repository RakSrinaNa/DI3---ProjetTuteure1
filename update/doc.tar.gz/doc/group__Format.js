var group__Format =
[
    [ "Dictionary based formatting functions", "group__Dictionary.html", "group__Dictionary" ],
    [ "Print format model management", "group__PrintFormat.html", "group__PrintFormat" ],
    [ "Print preview of a document", "group__Print.html", "group__Print" ]
];