var searchData=
[
  ['basepath',['BASEPATH',['../Config_8h.html#a617d5cce29915439bd7b51852c71e5ed',1,'Config.h']]]
];
