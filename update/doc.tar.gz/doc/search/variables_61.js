var searchData=
[
  ['address',['address',['../structCustomerRecord.html#a666f073c79b58211733013b9e7217567',1,'CustomerRecord']]],
  ['alignment',['alignment',['../structCatalogRecord__FieldProperties.html#a9b609437b0a9c5266747f6a31b8bf90e',1,'CatalogRecord_FieldProperties::alignment()'],['../structCustomerRecord__FieldProperties.html#a9b609437b0a9c5266747f6a31b8bf90e',1,'CustomerRecord_FieldProperties::alignment()']]]
];
