var searchData=
[
  ['quantity',['quantity',['../structDocumentRow.html#a42a7cbf17ad499bb36ad798c4bb46973',1,'DocumentRow']]],
  ['quotation',['QUOTATION',['../group__Document.html#gga69c49c41d38ae1dcaa0f31a22b1efee6a356b4a530320c31af5a30367b5d390ea',1,'Document.h']]],
  ['quotation_2eh',['Quotation.h',['../Quotation_8h.html',1,'']]],
  ['quotation_5fconverttobill',['Quotation_convertToBill',['../group__Quotation.html#gab94d323d46e6eb1c4f29ce8af4abe3f2',1,'Quotation.h']]],
  ['quotation_5fdisplay',['Quotation_display',['../group__Quotation.html#ga3e69cced2caba9255cd3534d3198087e',1,'Quotation.h']]],
  ['quotation_5fload',['Quotation_load',['../group__Quotation.html#ga8b96d36eba53f240787601e99330b728',1,'Quotation.h']]],
  ['quotation_5fnew',['Quotation_new',['../group__Quotation.html#ga949073ac775dbfbfe2beabcd705d88b2',1,'Quotation.h']]],
  ['quotation_5fopen',['Quotation_open',['../group__Quotation.html#ga2d735e0cb5f3ee786c6c21dfda2976ad',1,'Quotation.h']]],
  ['quotation_5fsave',['Quotation_save',['../group__Quotation.html#ga9c63283cb7fe9b966d6d0111823fd441',1,'Quotation.h']]]
];
