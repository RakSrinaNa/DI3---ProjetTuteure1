var searchData=
[
  ['parent',['parent',['../struct__GtkCatalogModel.html#a119e262dd6f86f1488d00a7ce2d28abf',1,'_GtkCatalogModel::parent()'],['../struct__GtkCustomerModel.html#a119e262dd6f86f1488d00a7ce2d28abf',1,'_GtkCustomerModel::parent()']]],
  ['parent_5fclass',['parent_class',['../struct__GtkCatalogModelClass.html#af6eccf80858ff5e5b9385f80ccdefa7c',1,'_GtkCatalogModelClass::parent_class()'],['../struct__GtkCustomerModelClass.html#af6eccf80858ff5e5b9385f80ccdefa7c',1,'_GtkCustomerModelClass::parent_class()']]],
  ['postalcode',['postalCode',['../structCustomerRecord.html#abc78132ec841694bdd43cd0033dc4c3f',1,'CustomerRecord']]]
];
