var searchData=
[
  ['catalogrecord_5ffunction_5fgetvalue',['CatalogRecord_Function_getValue',['../group__CatalogRecordEditor.html#gaabe668273b2697f1b0f0fcf70e058825',1,'CatalogRecordEditor.h']]],
  ['catalogrecord_5ffunction_5fisvaluevalid',['CatalogRecord_Function_isValueValid',['../group__CatalogRecordEditor.html#gabe3f5b919939e899ad5cc5262e40d417',1,'CatalogRecordEditor.h']]],
  ['catalogrecord_5ffunction_5fsetvalue',['CatalogRecord_Function_setValue',['../group__CatalogRecordEditor.html#gaa69f8d823a289f121f36e1e114952644',1,'CatalogRecordEditor.h']]],
  ['customerrecord_5ffunction_5fgetvalue',['CustomerRecord_Function_getValue',['../group__CustomerRecordEditor.html#ga6b0cd15fd443e45900a51a8f1245e04f',1,'CustomerRecordEditor.h']]],
  ['customerrecord_5ffunction_5fisvaluevalid',['CustomerRecord_Function_isValueValid',['../group__CustomerRecordEditor.html#ga27d82ace898ecbee18aef05622752c59',1,'CustomerRecordEditor.h']]],
  ['customerrecord_5ffunction_5fsetvalue',['CustomerRecord_Function_setValue',['../group__CustomerRecordEditor.html#ga89be30573eab1879bbdd4e5da95067c6',1,'CustomerRecordEditor.h']]]
];
