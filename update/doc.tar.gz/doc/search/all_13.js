var searchData=
[
  ['utility_20functions_20for_20documents',['Utility functions for documents',['../group__DocumentUtil.html',1,'']]],
  ['undefined_5fentry',['UNDEFINED_ENTRY',['../group__Dictionary.html#gga5214a8d7dc24ea08107746367d87bcf5adacf2705e5fbf7709a8e3442661f991c',1,'Dictionary.h']]],
  ['unit_20tests',['Unit tests',['../group__UnitTest.html',1,'']]],
  ['unittest_2eh',['UnitTest.h',['../UnitTest_8h.html',1,'']]],
  ['unity',['unity',['../structCatalogRecord.html#a9e8ebe5266edb99433e33a7e8b8956ce',1,'CatalogRecord::unity()'],['../structDocumentRow.html#a9e8ebe5266edb99433e33a7e8b8956ce',1,'DocumentRow::unity()']]],
  ['unused',['UNUSED',['../Config_8h.html#a0bdd8a945caf2eb28640128d1fed930c',1,'Config.h']]]
];
