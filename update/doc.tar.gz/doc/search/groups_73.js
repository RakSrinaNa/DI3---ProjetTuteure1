var searchData=
[
  ['string_20utility_20functions',['String utility functions',['../group__String.html',1,'']]],
  ['string_20related_20stuffs',['String related stuffs',['../group__Strings.html',1,'']]]
];
