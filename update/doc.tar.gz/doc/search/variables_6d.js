var searchData=
[
  ['maxlength',['maxlength',['../structCatalogRecord__FieldProperties.html#a601639a266b6cd1b91eddacff854c9ac',1,'CatalogRecord_FieldProperties::maxlength()'],['../structCustomerRecord__FieldProperties.html#a601639a266b6cd1b91eddacff854c9ac',1,'CustomerRecord_FieldProperties::maxlength()']]],
  ['mindisplaywidth',['minDisplayWidth',['../structCatalogRecord__FieldProperties.html#a0e040e466cb33f8dfab26c9a85b66278',1,'CatalogRecord_FieldProperties::minDisplayWidth()'],['../structCustomerRecord__FieldProperties.html#a0e040e466cb33f8dfab26c9a85b66278',1,'CustomerRecord_FieldProperties::minDisplayWidth()']]]
];
