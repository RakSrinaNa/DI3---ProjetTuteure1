var searchData=
[
  ['modify_5fdocument',['MODIFY_DOCUMENT',['../group__DocumentEditor.html#ggac02d640352b5046fac70aa514ef3ffa5a9f8fed1017add5b018cbe6a4ee43a4cb',1,'DocumentEditor.h']]]
];
