var searchData=
[
  ['header',['header',['../structPrintFormat.html#a2363a05c36ad2d4313f665fade072374',1,'PrintFormat']]]
];
