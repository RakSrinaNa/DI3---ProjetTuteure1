var searchData=
[
  ['management_20of_20the_20catalog_20of_20products',['Management of the catalog of products',['../group__CatalogUI.html',1,'']]],
  ['management_20of_20the_20customers',['Management of the customers',['../group__CustomerUI.html',1,'']]],
  ['mainwindow_2eh',['MainWindow.h',['../MainWindow_8h.html',1,'']]],
  ['mainwindow_5fcreate',['MainWindow_create',['../group__App.html#ga0f92704dd268924f59a056459a53d495',1,'MainWindow.h']]],
  ['makelowercasestring',['makeLowerCaseString',['../group__String.html#ga24474e839219f968eb6703cc91890448',1,'MyString.h']]],
  ['makeuppercasestring',['makeUpperCaseString',['../group__String.html#ga94cb2e274b32093588f987e530249f68',1,'MyString.h']]],
  ['malloc',['malloc',['../Config_8h.html#abea984d1fd4c0b19f0d70615ea64e2a1',1,'Config.h']]],
  ['maxlength',['maxlength',['../structCatalogRecord__FieldProperties.html#a601639a266b6cd1b91eddacff854c9ac',1,'CatalogRecord_FieldProperties::maxlength()'],['../structCustomerRecord__FieldProperties.html#a601639a266b6cd1b91eddacff854c9ac',1,'CustomerRecord_FieldProperties::maxlength()']]],
  ['maxvalue',['MAXVALUE',['../Config_8h.html#a305e727a769118647a7609e79221d7dd',1,'Config.h']]],
  ['memmove',['memmove',['../Config_8h.html#a802c986820d3866639922b6bc9484f90',1,'Config.h']]],
  ['memset',['memset',['../Config_8h.html#ace6ee45c30e71865e6eb635200379db9',1,'Config.h']]],
  ['mindisplaywidth',['minDisplayWidth',['../structCatalogRecord__FieldProperties.html#a0e040e466cb33f8dfab26c9a85b66278',1,'CatalogRecord_FieldProperties::minDisplayWidth()'],['../structCustomerRecord__FieldProperties.html#a0e040e466cb33f8dfab26c9a85b66278',1,'CustomerRecord_FieldProperties::minDisplayWidth()']]],
  ['modify_5fdocument',['MODIFY_DOCUMENT',['../group__DocumentEditor.html#ggac02d640352b5046fac70aa514ef3ffa5a9f8fed1017add5b018cbe6a4ee43a4cb',1,'DocumentEditor.h']]],
  ['mystring_2eh',['MyString.h',['../MyString_8h.html',1,'']]],
  ['mystringunit_2eh',['MyStringUnit.h',['../MyStringUnit_8h.html',1,'']]],
  ['management_20of_20the_20operators',['Management of the operators',['../group__Operator.html',1,'']]]
];
