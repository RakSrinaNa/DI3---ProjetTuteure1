var searchData=
[
  ['display_5fdocument',['DISPLAY_DOCUMENT',['../group__DocumentEditor.html#ggac02d640352b5046fac70aa514ef3ffa5ac85fa0a5349bb01ba45d56e1fe0aed10',1,'DocumentEditor.h']]]
];
