var searchData=
[
  ['new_5fdocument',['NEW_DOCUMENT',['../group__DocumentEditor.html#ggac02d640352b5046fac70aa514ef3ffa5a3780f381b44ad22db195fa9c673fab3a',1,'DocumentEditor.h']]],
  ['number_5fentry',['NUMBER_ENTRY',['../group__Dictionary.html#gga5214a8d7dc24ea08107746367d87bcf5aeab05e6cdb654edc01ab22ab6234cf5c',1,'Dictionary.h']]]
];
