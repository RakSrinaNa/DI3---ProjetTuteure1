var searchData=
[
  ['functions_20for_20bill_20management',['Functions for bill management',['../group__Bill.html',1,'']]],
  ['functions_20for_20editing_20documents',['Functions for editing documents',['../group__DocumentEditor.html',1,'']]],
  ['functions_20for_20quotation_20management',['Functions for quotation management',['../group__Quotation.html',1,'']]]
];
