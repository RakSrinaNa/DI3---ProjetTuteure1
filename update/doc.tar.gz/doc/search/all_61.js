var searchData=
[
  ['address',['address',['../structCustomerRecord.html#a666f073c79b58211733013b9e7217567',1,'CustomerRecord']]],
  ['alignment',['alignment',['../structCatalogRecord__FieldProperties.html#a9b609437b0a9c5266747f6a31b8bf90e',1,'CatalogRecord_FieldProperties::alignment()'],['../structCustomerRecord__FieldProperties.html#a9b609437b0a9c5266747f6a31b8bf90e',1,'CustomerRecord_FieldProperties::alignment()']]],
  ['application_20main_20functions',['Application main functions',['../group__App.html',1,'']]],
  ['app_2eh',['App.h',['../App_8h.html',1,'']]],
  ['app_5frun',['App_run',['../group__App.html#ga564bea34c350b6eb513aa2ac2e512c5f',1,'App.h']]],
  ['assert',['ASSERT',['../group__UnitTest.html#ga0966b817b229d48e5ffc7feab19a0be6',1,'UnitTest.h']]],
  ['assert_5fequal',['ASSERT_EQUAL',['../group__UnitTest.html#ga07fc9e3c2fa55f275fe572e4bb251316',1,'UnitTest.h']]],
  ['assert_5fequal_5fdouble',['ASSERT_EQUAL_DOUBLE',['../group__UnitTest.html#gac0d4e17fdbe3f5ff8259f519d8a83973',1,'UnitTest.h']]],
  ['assert_5fequal_5fstring',['ASSERT_EQUAL_STRING',['../group__UnitTest.html#gadc6e9fd7e1a6de46fe249b6acc1ea809',1,'UnitTest.h']]],
  ['assert_5fnot_5fequal',['ASSERT_NOT_EQUAL',['../group__UnitTest.html#gab5429200bb3a859fbfa99b52ec314883',1,'UnitTest.h']]],
  ['a_20specialized_20treeview_20model_20backed_20by_20our_20data_20structure_20instead_20of_20gtk_2b_20ones',['A specialized treeview model backed by our data structure instead of GTK+ ones',['../group__GtkCatalogModel.html',1,'']]],
  ['a_20specialized_20treeview_20model_20backed_20by_20our_20data_20structure_20instead_20of_20gtk_2b_20ones',['A specialized treeview model backed by our data structure instead of GTK+ ones',['../group__GtkCustomerModel.html',1,'']]]
];
