var searchData=
[
  ['operator_20related_20stuff',['Operator related stuff',['../group__Operators.html',1,'']]],
  ['operator_20database',['Operator database',['../group__OperatorTable.html',1,'']]]
];
