var searchData=
[
  ['designation',['designation',['../structCatalogRecord.html#a238af89adb357ae219950bae456a4d07',1,'CatalogRecord::designation()'],['../structDocumentRow.html#a238af89adb357ae219950bae456a4d07',1,'DocumentRow::designation()']]],
  ['discount',['discount',['../structDocumentRow.html#a53313c66e4ab6acce975994de1d9c097',1,'DocumentRow']]],
  ['docnumber',['docNumber',['../structDocument.html#a1606cdf3e0822d63297a546f4f0172dc',1,'Document']]]
];
