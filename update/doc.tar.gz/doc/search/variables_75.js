var searchData=
[
  ['unity',['unity',['../structCatalogRecord.html#a9e8ebe5266edb99433e33a7e8b8956ce',1,'CatalogRecord::unity()'],['../structDocumentRow.html#a9e8ebe5266edb99433e33a7e8b8956ce',1,'DocumentRow::unity()']]]
];
