var searchData=
[
  ['operatortable',['OperatorTable',['../structOperatorTable.html',1,'']]]
];
