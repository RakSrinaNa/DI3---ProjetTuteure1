var searchData=
[
  ['rateofvat',['rateOfVAT',['../structCatalogRecord.html#a9b94cceae6d68929f7e6065540058f1d',1,'CatalogRecord::rateOfVAT()'],['../structDocumentRow.html#a9b94cceae6d68929f7e6065540058f1d',1,'DocumentRow::rateOfVAT()']]],
  ['recordcount',['recordCount',['../structCatalogDB.html#af2b3801705d4d78cc1f2ede923a177e6',1,'CatalogDB::recordCount()'],['../structCustomerDB.html#af2b3801705d4d78cc1f2ede923a177e6',1,'CustomerDB::recordCount()'],['../structOperatorTable.html#af2b3801705d4d78cc1f2ede923a177e6',1,'OperatorTable::recordCount()']]],
  ['records',['records',['../structOperatorTable.html#a2b8fec4d9fcfdf4fc51875d37a0e44e2',1,'OperatorTable']]],
  ['row',['row',['../structPrintFormat.html#a4d6d80134097f21720b5f89c534135a2',1,'PrintFormat']]],
  ['rows',['rows',['../structDocument.html#afb959b3b54681ede558d5e86b9990661',1,'Document']]]
];
