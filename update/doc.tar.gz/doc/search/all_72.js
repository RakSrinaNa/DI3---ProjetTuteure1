var searchData=
[
  ['rateofvat',['rateOfVAT',['../structCatalogRecord.html#a9b94cceae6d68929f7e6065540058f1d',1,'CatalogRecord::rateOfVAT()'],['../structDocumentRow.html#a9b94cceae6d68929f7e6065540058f1d',1,'DocumentRow::rateOfVAT()']]],
  ['readstring',['readString',['../group__DocumentUtil.html#ga8b95856984309ee3bb50c4caa7259d63',1,'DocumentUtil.h']]],
  ['recordcount',['recordCount',['../structCatalogDB.html#af2b3801705d4d78cc1f2ede923a177e6',1,'CatalogDB::recordCount()'],['../structCustomerDB.html#af2b3801705d4d78cc1f2ede923a177e6',1,'CustomerDB::recordCount()'],['../structOperatorTable.html#af2b3801705d4d78cc1f2ede923a177e6',1,'OperatorTable::recordCount()']]],
  ['records',['records',['../structOperatorTable.html#a2b8fec4d9fcfdf4fc51875d37a0e44e2',1,'OperatorTable']]],
  ['registry_2eh',['Registry.h',['../Registry_8h.html',1,'']]],
  ['registry_5fdumpusage',['Registry_dumpUsage',['../Registry_8h.html#a7011b21a24e6f447a85079b0a1744efd',1,'Registry.h']]],
  ['registry_5finit',['Registry_init',['../Registry_8h.html#adb5515276462ff6c3271b26100f6c8f3',1,'Registry.h']]],
  ['registry_5fusingfunction',['REGISTRY_USINGFUNCTION',['../Registry_8h.html#acf9f693da4c3eae7b4af21fc2f86fcd6',1,'REGISTRY_USINGFUNCTION():&#160;Registry.h'],['../Registry_8h.html#a0caca2fa092d5c0feb6bd61fc0eceba9',1,'Registry_usingFunction(const char *name, const char *file):&#160;Registry.h']]],
  ['row',['row',['../structPrintFormat.html#a4d6d80134097f21720b5f89c534135a2',1,'PrintFormat']]],
  ['rows',['rows',['../structDocument.html#afb959b3b54681ede558d5e86b9990661',1,'Document']]],
  ['run_5ftest',['RUN_TEST',['../group__UnitTest.html#ga6d22b2e20a26b0d72b5c15912b4e211e',1,'UnitTest.h']]],
  ['runtest',['runtest',['../group__UnitTest.html#ga4a1df91db551d0a4f51a7239911e28fc',1,'UnitTest.h']]]
];
