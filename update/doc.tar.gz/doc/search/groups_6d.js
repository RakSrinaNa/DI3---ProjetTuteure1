var searchData=
[
  ['management_20of_20the_20catalog_20of_20products',['Management of the catalog of products',['../group__CatalogUI.html',1,'']]],
  ['management_20of_20the_20customers',['Management of the customers',['../group__CustomerUI.html',1,'']]],
  ['management_20of_20the_20operators',['Management of the operators',['../group__Operator.html',1,'']]]
];
