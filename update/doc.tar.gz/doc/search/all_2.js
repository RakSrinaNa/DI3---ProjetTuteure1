var searchData=
[
  ['basepath',['BASEPATH',['../Config_8h.html#a617d5cce29915439bd7b51852c71e5ed',1,'Config.h']]],
  ['baseprice',['basePrice',['../structCatalogRecord.html#aa202ff7ac9da4792e13c732cecd057cd',1,'CatalogRecord::basePrice()'],['../structDocumentRow.html#aa202ff7ac9da4792e13c732cecd057cd',1,'DocumentRow::basePrice()']]],
  ['begin_5ftests',['BEGIN_TESTS',['../group__UnitTest.html#gac5bac33688f7989a651226752508d64f',1,'UnitTest.h']]],
  ['bill',['BILL',['../group__Document.html#gga69c49c41d38ae1dcaa0f31a22b1efee6ac0f09f1fa0d8fde763958ffed01d6708',1,'Document.h']]],
  ['bill_2eh',['Bill.h',['../Bill_8h.html',1,'']]],
  ['bill_5fdisplay',['Bill_display',['../group__Bill.html#ga5669bf10066d2f7dd6c7272620961eec',1,'Bill.h']]],
  ['bill_5fload',['Bill_load',['../group__Bill.html#ga0328070d7678d062b2b1acec17bd2b8d',1,'Bill.h']]],
  ['bill_5fnew',['Bill_new',['../group__Bill.html#ga62d9c83a8ba17a3150a27e595dede22a',1,'Bill.h']]],
  ['bill_5fopen',['Bill_open',['../group__Bill.html#gab29e20b6cf63c266f73f9683cb069347',1,'Bill.h']]],
  ['bill_5fsave',['Bill_save',['../group__Bill.html#ga01c210e84863e05985aa7aa064471e53',1,'Bill.h']]]
];
