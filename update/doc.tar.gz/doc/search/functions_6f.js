var searchData=
[
  ['operator_5fidentify',['Operator_identify',['../group__Operator.html#ga2fadfdfb6628763e4688d163f61e294a',1,'Operator.h']]],
  ['operator_5fmanage',['Operator_manage',['../group__Operator.html#ga8433c15a18c9ec1c7bcc0ac157ea6365',1,'Operator.h']]],
  ['operatortable_5fcreate',['OperatorTable_create',['../group__OperatorTable.html#ga0946083652409c446ea726955f3cdb19',1,'OperatorTable']]],
  ['operatortable_5fdestroy',['OperatorTable_destroy',['../group__OperatorTable.html#ga093ffd7811f1c2a89ab635507c4bba96',1,'OperatorTable']]],
  ['operatortable_5ffindoperator',['OperatorTable_findOperator',['../group__OperatorTable.html#gace3423bb62bb53c82246a7b0836aba1f',1,'OperatorTable']]],
  ['operatortable_5fgetname',['OperatorTable_getName',['../group__OperatorTable.html#ga54c88fb068c98e5a1bc9434a6c4c996c',1,'OperatorTable']]],
  ['operatortable_5fgetpassword',['OperatorTable_getPassword',['../group__OperatorTable.html#ga013c78a66e05f18f9c61e3c855a1316e',1,'OperatorTable']]],
  ['operatortable_5fgetrecordcount',['OperatorTable_getRecordCount',['../group__OperatorTable.html#gaa672bf09dd0fa4fb2e2f96c55499524f',1,'OperatorTable']]],
  ['operatortable_5floadfromfile',['OperatorTable_loadFromFile',['../group__OperatorTable.html#gaa4bb5af08622744acd8b8d41336a0aa7',1,'OperatorTable']]],
  ['operatortable_5fremoverecord',['OperatorTable_removeRecord',['../group__OperatorTable.html#ga60bf15e24a5ffd31ddbcb6fa37ffcde3',1,'OperatorTable']]],
  ['operatortable_5fsavetofile',['OperatorTable_saveToFile',['../group__OperatorTable.html#ga360f5666fbbcb6f5723c155b888ad8a8',1,'OperatorTable']]],
  ['operatortable_5fsetoperator',['OperatorTable_setOperator',['../group__OperatorTable.html#ga46c75a5c2c8b1eeb06b24f7cbc60c229',1,'OperatorTable']]]
];
