var searchData=
[
  ['extern',['extern',['../Config_8h.html#a2a624a765564411c0db3a2bee940f8bc',1,'Config.h']]]
];
