var searchData=
[
  ['editdate',['editDate',['../structDocument.html#a312899691f7ecdb742ca28504d7238c5',1,'Document']]],
  ['entries',['entries',['../structDictionary.html#a004fd00597fc71cffde7e5ad5d34c4d7',1,'Dictionary']]],
  ['expirydate',['expiryDate',['../structDocument.html#ad473f0686021470bca3be3ceae698139',1,'Document']]]
];
