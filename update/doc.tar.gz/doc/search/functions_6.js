var searchData=
[
  ['gtkcatalogmodel_5fappend_5frecord',['GtkCatalogModel_append_record',['../group__GtkCatalogModel.html#ga9db2d80542fb498f24a7a98a3c8b37b4',1,'GtkCatalogModel.h']]],
  ['gtkcatalogmodel_5fchange_5frecord',['GtkCatalogModel_change_record',['../group__GtkCatalogModel.html#ga15ca1d2f9b1eb7ae6577ea17846a1367',1,'GtkCatalogModel.h']]],
  ['gtkcatalogmodel_5fget_5ftype',['GtkCatalogModel_get_type',['../group__GtkCatalogModel.html#ga2085390f66b0f2353e043cedc7037a2d',1,'GtkCatalogModel.h']]],
  ['gtkcatalogmodel_5finsert_5frecord',['GtkCatalogModel_insert_record',['../group__GtkCatalogModel.html#ga98ffaceae96f8457675f7fd025842f6c',1,'GtkCatalogModel.h']]],
  ['gtkcatalogmodel_5fnew',['GtkCatalogModel_new',['../group__GtkCatalogModel.html#ga113f141feccff1fd3c4ab9581ee92fe6',1,'GtkCatalogModel.h']]],
  ['gtkcatalogmodel_5fremove_5frecord',['GtkCatalogModel_remove_record',['../group__GtkCatalogModel.html#gaaa18696a43ce08985f84ce2a406933d5',1,'GtkCatalogModel.h']]],
  ['gtkcustomermodel_5fappend_5frecord',['GtkCustomerModel_append_record',['../group__GtkCustomerModel.html#ga740f604e984c1a1bdcf8686f77a1641b',1,'GtkCustomerModel.h']]],
  ['gtkcustomermodel_5fchange_5frecord',['GtkCustomerModel_change_record',['../group__GtkCustomerModel.html#ga6dc833e658a293271ddf8f44e5bc528a',1,'GtkCustomerModel.h']]],
  ['gtkcustomermodel_5fget_5ftype',['GtkCustomerModel_get_type',['../group__GtkCustomerModel.html#gac5cc050a4867bff4661c6b69d0cc4c69',1,'GtkCustomerModel.h']]],
  ['gtkcustomermodel_5finsert_5frecord',['GtkCustomerModel_insert_record',['../group__GtkCustomerModel.html#ga684fad5cef4f73d6d92488ebad0acf57',1,'GtkCustomerModel.h']]],
  ['gtkcustomermodel_5fnew',['GtkCustomerModel_new',['../group__GtkCustomerModel.html#ga97b902acd6f4166b4b2661fd6aa21f1a',1,'GtkCustomerModel.h']]],
  ['gtkcustomermodel_5fremove_5frecord',['GtkCustomerModel_remove_record',['../group__GtkCustomerModel.html#ga99592941d1c02172bcdca1712027e564',1,'GtkCustomerModel.h']]]
];
