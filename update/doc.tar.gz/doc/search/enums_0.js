var searchData=
[
  ['catalogrecord_5ffieldidentifier',['CatalogRecord_FieldIdentifier',['../group__CatalogRecordEditor.html#ga3833ced63c1c0a11655447e5136c2ca7',1,'CatalogRecordEditor.h']]],
  ['customerrecord_5ffieldidentifier',['CustomerRecord_FieldIdentifier',['../group__CustomerRecordEditor.html#gaf7d20c2811247cc46892396dd8594389',1,'CustomerRecordEditor.h']]]
];
