var searchData=
[
  ['registry_2eh',['Registry.h',['../Registry_8h.html',1,'']]]
];
