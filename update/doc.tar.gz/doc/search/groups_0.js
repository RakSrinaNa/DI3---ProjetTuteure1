var searchData=
[
  ['application_20main_20functions',['Application main functions',['../group__App.html',1,'']]],
  ['a_20specialized_20treeview_20model_20backed_20by_20our_20data_20structure_20instead_20of_20gtk_2b_20ones',['A specialized treeview model backed by our data structure instead of GTK+ ones',['../group__GtkCatalogModel.html',1,'']]],
  ['a_20specialized_20treeview_20model_20backed_20by_20our_20data_20structure_20instead_20of_20gtk_2b_20ones',['A specialized treeview model backed by our data structure instead of GTK+ ones',['../group__GtkCustomerModel.html',1,'']]]
];
