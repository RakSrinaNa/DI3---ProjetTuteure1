var structCustomerRecord =
[
    [ "CustomerRecord_edit", "group__CustomerRecordEditor.html#ga54cbf0b508d808fd6665248f83240455", null ],
    [ "CustomerRecord_finalize", "group__CustomerRecord.html#ga6c43ed660b9e3789cca3b7fe87a5b235", null ],
    [ "CustomerRecord_getFieldProperties", "group__CustomerRecordEditor.html#ga65de9a142281fa3532e85d3c09b6f523", null ],
    [ "CustomerRecord_init", "group__CustomerRecord.html#ga8ebf543722d2f309b318f87e591e86ae", null ],
    [ "CustomerRecord_read", "group__CustomerRecord.html#ga12270b2635140d7a72cc2a7aaa49169d", null ],
    [ "CustomerRecord_write", "group__CustomerRecord.html#ga0d3a15ee68f0bddf5e24940230ea737d", null ],
    [ "address", "structCustomerRecord.html#a666f073c79b58211733013b9e7217567", null ],
    [ "name", "structCustomerRecord.html#a479b51f76b74245617707fc5e9f38da0", null ],
    [ "postalCode", "structCustomerRecord.html#abc78132ec841694bdd43cd0033dc4c3f", null ],
    [ "town", "structCustomerRecord.html#a30a63918799464a65616e4b159126e66", null ]
];