var group__Document =
[
    [ "Document", "structDocument.html", [
      [ "customer", "structDocument.html#ae09cf2ecc5299bb3926980664c473fd3", null ],
      [ "docNumber", "structDocument.html#a1606cdf3e0822d63297a546f4f0172dc", null ],
      [ "editDate", "structDocument.html#a312899691f7ecdb742ca28504d7238c5", null ],
      [ "expiryDate", "structDocument.html#ad473f0686021470bca3be3ceae698139", null ],
      [ "object", "structDocument.html#a698139783a57ed0223f42bff714b914b", null ],
      [ "operator", "structDocument.html#a4929e9d61af65aab9bcf3eae097f2555", null ],
      [ "rows", "structDocument.html#afb959b3b54681ede558d5e86b9990661", null ],
      [ "typeDocument", "structDocument.html#ad2e6abc5a91c6708161b80bba3facc28", null ]
    ] ],
    [ "TypeDocument", "group__Document.html#ga69c49c41d38ae1dcaa0f31a22b1efee6", [
      [ "QUOTATION", "group__Document.html#gga69c49c41d38ae1dcaa0f31a22b1efee6a356b4a530320c31af5a30367b5d390ea", null ],
      [ "BILL", "group__Document.html#gga69c49c41d38ae1dcaa0f31a22b1efee6ac0f09f1fa0d8fde763958ffed01d6708", null ]
    ] ],
    [ "Document_finalize", "group__Document.html#gacd07ee9b169977b74bcd8b5256042f8e", null ],
    [ "Document_init", "group__Document.html#ga103dd74efd5e151c551abbdc398e810d", null ],
    [ "Document_loadFromFile", "group__Document.html#ga7fdd2a2812aa902e090469075e802028", null ],
    [ "Document_saveToFile", "group__Document.html#ga6bfc6a1d00c1a093a670392bc81a58d9", null ]
];