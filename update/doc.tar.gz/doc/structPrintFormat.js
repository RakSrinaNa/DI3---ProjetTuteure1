var structPrintFormat =
[
    [ "footer", "structPrintFormat.html#accec40ba2ef7b5747c909005cd1e66dd", null ],
    [ "header", "structPrintFormat.html#a2363a05c36ad2d4313f665fade072374", null ],
    [ "name", "structPrintFormat.html#a5ac083a645d964373f022d03df4849c8", null ],
    [ "row", "structPrintFormat.html#a4d6d80134097f21720b5f89c534135a2", null ]
];