var DocumentEditor_8h =
[
    [ "TypeAction", "group__DocumentEditor.html#gac02d640352b5046fac70aa514ef3ffa5", [
      [ "NEW_DOCUMENT", "group__DocumentEditor.html#ggac02d640352b5046fac70aa514ef3ffa5a3780f381b44ad22db195fa9c673fab3a", null ],
      [ "DISPLAY_DOCUMENT", "group__DocumentEditor.html#ggac02d640352b5046fac70aa514ef3ffa5ac85fa0a5349bb01ba45d56e1fe0aed10", null ],
      [ "MODIFY_DOCUMENT", "group__DocumentEditor.html#ggac02d640352b5046fac70aa514ef3ffa5a9f8fed1017add5b018cbe6a4ee43a4cb", null ]
    ] ],
    [ "DocumentEditor_edit", "group__DocumentEditor.html#ga81e9796adf3183dbc2126507265e510a", null ]
];