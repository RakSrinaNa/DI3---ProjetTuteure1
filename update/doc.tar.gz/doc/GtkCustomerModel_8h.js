var GtkCustomerModel_8h =
[
    [ "GTKCUSTOMERMODEL", "group__GtkCustomerModel.html#ga75031bb34535282b4906531c39578f7c", null ],
    [ "GTKCUSTOMERMODEL_CLASS", "group__GtkCustomerModel.html#ga441697cc5a5077a1f89454fedb485630", null ],
    [ "GTKCUSTOMERMODEL_IS_LIST", "group__GtkCustomerModel.html#ga4a41fa000b3bc76fd69d73d8fa8cf648", null ],
    [ "GTKCUSTOMERMODEL_IS_LIST_CLASS", "group__GtkCustomerModel.html#ga8ed58a5019ae446da16f8649d53609ad", null ],
    [ "GTKCUSTOMERMODEL_LIST_GET_CLASS", "group__GtkCustomerModel.html#gaa253327a2960ff5ecbfced4490595e12", null ],
    [ "GTKCUSTOMERMODEL_TYPE_LIST", "group__GtkCustomerModel.html#ga9da64829312943c283a175c04fb6fc1d", null ],
    [ "GtkCustomerModel_append_record", "group__GtkCustomerModel.html#ga740f604e984c1a1bdcf8686f77a1641b", null ],
    [ "GtkCustomerModel_change_record", "group__GtkCustomerModel.html#ga6dc833e658a293271ddf8f44e5bc528a", null ],
    [ "GtkCustomerModel_get_type", "group__GtkCustomerModel.html#gac5cc050a4867bff4661c6b69d0cc4c69", null ],
    [ "GtkCustomerModel_insert_record", "group__GtkCustomerModel.html#ga684fad5cef4f73d6d92488ebad0acf57", null ],
    [ "GtkCustomerModel_new", "group__GtkCustomerModel.html#ga97b902acd6f4166b4b2661fd6aa21f1a", null ],
    [ "GtkCustomerModel_remove_record", "group__GtkCustomerModel.html#ga99592941d1c02172bcdca1712027e564", null ]
];