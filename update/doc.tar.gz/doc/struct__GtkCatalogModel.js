var struct__GtkCatalogModel =
[
    [ "catalogDB", "struct__GtkCatalogModel.html#a4d7999b935b08c419f385e5beddde6ee", null ],
    [ "parent", "struct__GtkCatalogModel.html#a119e262dd6f86f1488d00a7ce2d28abf", null ],
    [ "shouldCloseDB", "struct__GtkCatalogModel.html#aa9ba3ae86adc8c2b1efe995e7d600ea8", null ],
    [ "stamp", "struct__GtkCatalogModel.html#a0fa107e460911891fac8f819b2e7220b", null ]
];