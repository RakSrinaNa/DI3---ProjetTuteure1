var group__Strings =
[
    [ "String utility functions", "group__String.html", "group__String" ]
];