var structCustomerRecord__FieldProperties =
[
    [ "alignment", "structCustomerRecord__FieldProperties.html#a9b609437b0a9c5266747f6a31b8bf90e", null ],
    [ "getValue", "structCustomerRecord__FieldProperties.html#aee711177146c0cf48beda373745591a0", null ],
    [ "isValueValid", "structCustomerRecord__FieldProperties.html#a9260f4c76d4534d92365e49a32012e87", null ],
    [ "maxlength", "structCustomerRecord__FieldProperties.html#a601639a266b6cd1b91eddacff854c9ac", null ],
    [ "minDisplayWidth", "structCustomerRecord__FieldProperties.html#a0e040e466cb33f8dfab26c9a85b66278", null ],
    [ "name", "structCustomerRecord__FieldProperties.html#a8f8f80d37794cde9472343e4487ba3eb", null ],
    [ "setValue", "structCustomerRecord__FieldProperties.html#a8112f8b1f9d6e4af99e861890bd4d61a", null ],
    [ "size", "structCustomerRecord__FieldProperties.html#a439227feff9d7f55384e8780cfc2eb82", null ]
];