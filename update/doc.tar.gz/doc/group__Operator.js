var group__Operator =
[
    [ "Operator_identify", "group__Operator.html#ga2fadfdfb6628763e4688d163f61e294a", null ],
    [ "Operator_manage", "group__Operator.html#ga8433c15a18c9ec1c7bcc0ac157ea6365", null ]
];