var Document_8h =
[
    [ "TypeDocument", "group__Document.html#ga69c49c41d38ae1dcaa0f31a22b1efee6", [
      [ "QUOTATION", "group__Document.html#gga69c49c41d38ae1dcaa0f31a22b1efee6a356b4a530320c31af5a30367b5d390ea", null ],
      [ "BILL", "group__Document.html#gga69c49c41d38ae1dcaa0f31a22b1efee6ac0f09f1fa0d8fde763958ffed01d6708", null ]
    ] ],
    [ "Document_finalize", "group__Document.html#gacd07ee9b169977b74bcd8b5256042f8e", null ],
    [ "Document_init", "group__Document.html#ga103dd74efd5e151c551abbdc398e810d", null ],
    [ "Document_loadFromFile", "group__Document.html#ga7fdd2a2812aa902e090469075e802028", null ],
    [ "Document_saveToFile", "group__Document.html#ga6bfc6a1d00c1a093a670392bc81a58d9", null ]
];