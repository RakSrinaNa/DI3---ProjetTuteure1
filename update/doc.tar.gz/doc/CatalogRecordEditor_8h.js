var CatalogRecordEditor_8h =
[
    [ "CatalogRecord_Function_getValue", "group__CatalogRecordEditor.html#ga3826ca5da1fb53cdf75f281eae9b0ab1", null ],
    [ "CatalogRecord_Function_isValueValid", "group__CatalogRecordEditor.html#gab832f2a689f761a8ff2020e3c4d6ce55", null ],
    [ "CatalogRecord_Function_setValue", "group__CatalogRecordEditor.html#ga7c354a53cd523ca272071eec0cb14110", null ],
    [ "CatalogRecord_FieldIdentifier", "group__CatalogRecordEditor.html#ga3833ced63c1c0a11655447e5136c2ca7", [
      [ "CATALOGRECORD_CODE_FIELD", "group__CatalogRecordEditor.html#gga3833ced63c1c0a11655447e5136c2ca7a4d204dd316dccc3a199567e3dc36f2eb", null ],
      [ "CATALOGRECORD_DESIGNATION_FIELD", "group__CatalogRecordEditor.html#gga3833ced63c1c0a11655447e5136c2ca7a02bda3b6ab5088442000ebdb7253a9c0", null ],
      [ "CATALOGRECORD_UNITY_FIELD", "group__CatalogRecordEditor.html#gga3833ced63c1c0a11655447e5136c2ca7adf423818130c55d573b79b4438ac27a1", null ],
      [ "CATALOGRECORD_BASEPRICE_FIELD", "group__CatalogRecordEditor.html#gga3833ced63c1c0a11655447e5136c2ca7a5cdf683f1a32c539d62b89ef592875b8", null ],
      [ "CATALOGRECORD_SELLINGPRICE_FIELD", "group__CatalogRecordEditor.html#gga3833ced63c1c0a11655447e5136c2ca7a2064e6e10b7184e6f28ee31d8f11e631", null ],
      [ "CATALOGRECORD_RATEOFVAT_FIELD", "group__CatalogRecordEditor.html#gga3833ced63c1c0a11655447e5136c2ca7a7279207f2d7305e062cbde8e6d9e5437", null ],
      [ "CATALOGRECORD_FIELDCOUNT", "group__CatalogRecordEditor.html#gga3833ced63c1c0a11655447e5136c2ca7a4020258654f2faee99043dda081dedbd", null ]
    ] ]
];