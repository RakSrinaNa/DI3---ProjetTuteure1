var group__Documents =
[
    [ "Documents", "group__Document.html", "group__Document" ],
    [ "Functions for bill management", "group__Bill.html", "group__Bill" ],
    [ "Functions for editing documents", "group__DocumentEditor.html", "group__DocumentEditor" ],
    [ "Functions for quotation management", "group__Quotation.html", "group__Quotation" ],
    [ "List of rows of a document", "group__DocumentRowList.html", "group__DocumentRowList" ],
    [ "Utility functions for documents", "group__DocumentUtil.html", "group__DocumentUtil" ]
];