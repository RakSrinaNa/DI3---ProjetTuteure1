var group__Operators =
[
    [ "Management of the operators", "group__Operator.html", "group__Operator" ],
    [ "Operator database", "group__OperatorTable.html", "group__OperatorTable" ]
];