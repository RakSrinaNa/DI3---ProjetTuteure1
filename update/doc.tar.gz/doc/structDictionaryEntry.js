var structDictionaryEntry =
[
    [ "name", "structDictionaryEntry.html#a5ac083a645d964373f022d03df4849c8", null ],
    [ "numberValue", "structDictionaryEntry.html#aa5be9b9b70ba596fdb532a82d1a0647a", null ],
    [ "stringValue", "structDictionaryEntry.html#aed9e532713eec5e9729ebd0959d230c3", null ],
    [ "type", "structDictionaryEntry.html#a0b0cbec2271fe5a078a0e9a2eaec792a", null ],
    [ "value", "structDictionaryEntry.html#a7bd22536baf6a8650c128868c374713a", null ]
];