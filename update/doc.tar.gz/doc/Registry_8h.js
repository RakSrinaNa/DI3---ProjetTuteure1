var Registry_8h =
[
    [ "__func__", "Registry_8h.html#a7d6e1cf1a8d53f38471e9e9db3faf740", null ],
    [ "REGISTRY_USINGFUNCTION", "Registry_8h.html#acf9f693da4c3eae7b4af21fc2f86fcd6", null ],
    [ "Registry_dumpUsage", "Registry_8h.html#a7011b21a24e6f447a85079b0a1744efd", null ],
    [ "Registry_getUsage", "Registry_8h.html#a3187b9695c4172b80429bdb1ec4f51e6", null ],
    [ "Registry_init", "Registry_8h.html#adb5515276462ff6c3271b26100f6c8f3", null ],
    [ "Registry_usingFunction", "Registry_8h.html#a0caca2fa092d5c0feb6bd61fc0eceba9", null ]
];