var CustomerRecordEditor_8h =
[
    [ "CustomerRecord_Function_getValue", "group__CustomerRecordEditor.html#gaff30aa90df250fcd6482914495a38cde", null ],
    [ "CustomerRecord_Function_isValueValid", "group__CustomerRecordEditor.html#ga72bc69531600cf9e624b9e9a15669ca0", null ],
    [ "CustomerRecord_Function_setValue", "group__CustomerRecordEditor.html#gabc8423c0b3b39f9f4faedcdb050d5a2a", null ],
    [ "CustomerRecord_FieldIdentifier", "group__CustomerRecordEditor.html#gaf7d20c2811247cc46892396dd8594389", [
      [ "CUSTOMERRECORD_NAME_FIELD", "group__CustomerRecordEditor.html#ggaf7d20c2811247cc46892396dd8594389a7a2e070b01f18928ea53b0fd64275aee", null ],
      [ "CUSTOMERRECORD_ADDRESS_FIELD", "group__CustomerRecordEditor.html#ggaf7d20c2811247cc46892396dd8594389a0590a1a05f570ee1c3dd3622b6be71a7", null ],
      [ "CUSTOMERRECORD_POSTALCODE_FIELD", "group__CustomerRecordEditor.html#ggaf7d20c2811247cc46892396dd8594389a3e4dfeaab52a5d4a6d13449a5a985241", null ],
      [ "CUSTOMERRECORD_TOWN_FIELD", "group__CustomerRecordEditor.html#ggaf7d20c2811247cc46892396dd8594389a8a47be87596e842f07416c23f1311cfc", null ],
      [ "CUSTOMERRECORD_FIELDCOUNT", "group__CustomerRecordEditor.html#ggaf7d20c2811247cc46892396dd8594389acd4a93c9bbd1a38a083d0dd23bc50420", null ]
    ] ]
];