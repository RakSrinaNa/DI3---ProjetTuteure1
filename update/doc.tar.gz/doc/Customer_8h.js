var Customer_8h =
[
    [ "Customer_manage", "group__CustomerUI.html#gad0a68d1f54ac35f9c42de96ca832bd6e", null ],
    [ "Customer_select", "group__CustomerUI.html#ga3e50d0392f66722076c8474e8b99a286", null ]
];