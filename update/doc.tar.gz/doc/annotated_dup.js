var annotated_dup =
[
    [ "GtkCatalogModel", "struct__GtkCatalogModel.html", "struct__GtkCatalogModel" ],
    [ "GtkCatalogModelClass", "struct__GtkCatalogModelClass.html", "struct__GtkCatalogModelClass" ],
    [ "GtkCustomerModel", "struct__GtkCustomerModel.html", "struct__GtkCustomerModel" ],
    [ "GtkCustomerModelClass", "struct__GtkCustomerModelClass.html", "struct__GtkCustomerModelClass" ],
    [ "CatalogDB", "structCatalogDB.html", "structCatalogDB" ],
    [ "CatalogRecord", "structCatalogRecord.html", "structCatalogRecord" ],
    [ "CatalogRecord_FieldProperties", "structCatalogRecord__FieldProperties.html", "structCatalogRecord__FieldProperties" ],
    [ "CustomerDB", "structCustomerDB.html", "structCustomerDB" ],
    [ "CustomerRecord", "structCustomerRecord.html", "structCustomerRecord" ],
    [ "CustomerRecord_FieldProperties", "structCustomerRecord__FieldProperties.html", "structCustomerRecord__FieldProperties" ],
    [ "Dictionary", "structDictionary.html", "structDictionary" ],
    [ "DictionaryEntry", "structDictionaryEntry.html", "structDictionaryEntry" ],
    [ "Document", "structDocument.html", "structDocument" ],
    [ "DocumentRow", "structDocumentRow.html", "structDocumentRow" ],
    [ "OperatorTable", "structOperatorTable.html", "structOperatorTable" ],
    [ "PrintFormat", "structPrintFormat.html", "structPrintFormat" ]
];