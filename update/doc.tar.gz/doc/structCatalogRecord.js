var structCatalogRecord =
[
    [ "CatalogRecord_edit", "group__CatalogRecordEditor.html#ga2176fd095ada54d514f19126bc05cea1", null ],
    [ "CatalogRecord_finalize", "group__CatalogRecord.html#ga8823e779dd4b448e11870843c2f26f4d", null ],
    [ "CatalogRecord_getFieldProperties", "group__CatalogRecordEditor.html#ga64e48fd820803b196a1b1e2aa1aeb16b", null ],
    [ "CatalogRecord_init", "group__CatalogRecord.html#ga9691e16a453bb09d3bd4d0533be22371", null ],
    [ "CatalogRecord_read", "group__CatalogRecord.html#ga9b77150a2daa458456bdc0d37769ff3a", null ],
    [ "CatalogRecord_write", "group__CatalogRecord.html#ga645558a1fce53f1160a05a0dd93f6d09", null ],
    [ "basePrice", "structCatalogRecord.html#aa202ff7ac9da4792e13c732cecd057cd", null ],
    [ "code", "structCatalogRecord.html#a5b9e1322ebc26e12c192f03bccba2770", null ],
    [ "designation", "structCatalogRecord.html#a238af89adb357ae219950bae456a4d07", null ],
    [ "rateOfVAT", "structCatalogRecord.html#a9b94cceae6d68929f7e6065540058f1d", null ],
    [ "sellingPrice", "structCatalogRecord.html#a3ba5a6e4bf38bba226358967cfa33302", null ],
    [ "unity", "structCatalogRecord.html#a9e8ebe5266edb99433e33a7e8b8956ce", null ]
];