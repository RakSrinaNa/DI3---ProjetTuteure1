var OperatorTable_8h =
[
    [ "OPERATORTABLE_MAXNAMESIZE", "group__OperatorTable.html#ga4744ce294a17b76a8760c09a88f2058a", null ],
    [ "OPERATORTABLE_MAXPASSWORDSIZE", "group__OperatorTable.html#ga04cde054f97d7582da84e36b759c6856", null ],
    [ "OPERATORDB_FILENAME", "group__OperatorTable.html#gac2d35b6fa759c767fcd18df44b8bc13a", null ]
];