var Dictionary_8h =
[
    [ "DictionaryEntryType", "group__Dictionary.html#ga5214a8d7dc24ea08107746367d87bcf5", [
      [ "UNDEFINED_ENTRY", "group__Dictionary.html#gga5214a8d7dc24ea08107746367d87bcf5adacf2705e5fbf7709a8e3442661f991c", null ],
      [ "NUMBER_ENTRY", "group__Dictionary.html#gga5214a8d7dc24ea08107746367d87bcf5aeab05e6cdb654edc01ab22ab6234cf5c", null ],
      [ "STRING_ENTRY", "group__Dictionary.html#gga5214a8d7dc24ea08107746367d87bcf5a3876b394e48e8b65f1a8ea60aabf597f", null ]
    ] ],
    [ "Dictionary_create", "group__Dictionary.html#gae815a95f3fb6d1d61f72e395e65dda41", null ],
    [ "Dictionary_destroy", "group__Dictionary.html#ga3a1606923fafcf228ea67cb75947fab8", null ],
    [ "Dictionary_format", "group__Dictionary.html#ga8cfb4fc69b034c758cd0dd62235b1357", null ],
    [ "Dictionary_getEntry", "group__Dictionary.html#ga929d74c13e8d3eb63ac56ad468bf93b4", null ],
    [ "Dictionary_setNumberEntry", "group__Dictionary.html#ga98c0094297f891804961d8cb056c30bc", null ],
    [ "Dictionary_setStringEntry", "group__Dictionary.html#gab222ae16091015a68652bf2ff38d5dcf", null ]
];